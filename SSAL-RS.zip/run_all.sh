python run_experiments.py -e resnet50_baseline resnet50_ssal wrn28-10_baseline wrn28-10_ssal \
        densenet190-40_baseline densenet190-40_ssal